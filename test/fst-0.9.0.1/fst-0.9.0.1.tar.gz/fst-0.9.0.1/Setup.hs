#!/usr/bin/runhaskell

import Distribution.Simple

main = defaultMainWithHooks defaultUserHooks
