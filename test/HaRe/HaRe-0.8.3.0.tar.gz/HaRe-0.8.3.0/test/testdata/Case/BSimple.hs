module BSimple where
-- Test for refactor of if to case

foo x = if (odd x) then "Odd" else "Even"

