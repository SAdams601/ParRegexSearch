

main =
 if 1 > 10
   then do putStrLn "hello"
           putStrLn "there"
   else do putStrLn "blah"
           putStrLn "blah"
