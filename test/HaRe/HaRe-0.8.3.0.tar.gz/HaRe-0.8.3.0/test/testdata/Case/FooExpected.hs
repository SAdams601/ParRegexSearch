

main =
 case 1 > 10 of
   True  -> do putStrLn "hello"
               putStrLn "there"
   False -> do putStrLn "blah"
               putStrLn "blah"
