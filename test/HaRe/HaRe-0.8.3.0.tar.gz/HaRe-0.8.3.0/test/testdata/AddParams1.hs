module AddParams1 where

sq  0 = 0
sq  z = z^2

foo = 3

