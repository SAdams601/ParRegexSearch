module TypeSigs where

sq,anotherFun :: Int -> Int
sq 0 = 0
sq z = z^2

anotherFun x = x^2

a,b,c::Int->Integer->Char

a x y = undefined
b x y = undefined
c x y = undefined

