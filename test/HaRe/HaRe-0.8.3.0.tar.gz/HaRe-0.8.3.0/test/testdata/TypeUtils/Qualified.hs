-- module TypeUtils.Qualified where

import TypeUtils.C

main = return TypeUtils.C.baz
