module SelectivelyImports where

import Data.Maybe (fromJust)

__ = id
