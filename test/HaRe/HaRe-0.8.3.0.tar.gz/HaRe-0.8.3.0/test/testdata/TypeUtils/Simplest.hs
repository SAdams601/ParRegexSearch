module Simplest where


simple x = x
