module MultiFun1 where

{-

Remove the second parameter from every equation for the function foo.

-}

foo [] x = []
foo xs x = [1]

