module MultiFun1 where

{-

Remove the second parameter from every equation for the function foo.

-}

foo [] = []
foo xs = [1]

