module M2 (m2) where

import S1

m2 = s1 - 7


