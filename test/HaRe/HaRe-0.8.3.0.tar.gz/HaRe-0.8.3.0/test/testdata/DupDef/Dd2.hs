module DupDef.Dd2 where

import DupDef.Dd1


f2 x = ff (x+1)

mm = 5


