module DupDef.Dd3 where

import DupDef.Dd1 hiding (dd)


f2 x = ff (x+1)

mm = 5


