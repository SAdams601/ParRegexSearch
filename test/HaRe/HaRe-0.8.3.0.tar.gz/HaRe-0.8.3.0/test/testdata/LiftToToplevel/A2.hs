module LiftToToplevel.A2 where
 
import LiftToToplevel.C2 

main  = sumSquares [1..4] + anotherFun [1..4] 

