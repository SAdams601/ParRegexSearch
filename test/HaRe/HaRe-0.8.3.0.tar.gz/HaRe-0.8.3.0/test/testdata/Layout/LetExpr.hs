-- A simple let expression, to ensure the layout is detected

module Layout.LetExpr where

foo = let x = 1
          y = 2
      in x + y

