{-# LANGUAGE StandaloneDeriving   #-}
module Layout.Derive where

-- import Data.Generics

data B = B Integer

deriving instance Show B


