module Layout.Default where

default (Float,Integer,Double)


foo = 5
