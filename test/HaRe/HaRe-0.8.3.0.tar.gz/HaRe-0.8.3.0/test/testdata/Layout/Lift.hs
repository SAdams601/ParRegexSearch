module Layout.Lift where

ff y = y + zz
  where
    zz = 1

x = 1
