module Layout.FromMd1 where

data D = A | B String | C

ff :: Int -> Int
ff y = y + zz
  where
    zz = 1

x = 3
