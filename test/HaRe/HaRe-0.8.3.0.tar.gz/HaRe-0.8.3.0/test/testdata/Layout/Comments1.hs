module Layout.Comments1 where

aFun x = x + p
         where p=2  {-There is a comment-}

anotherFun = 3

