-- A simple case expression, to ensure the layout is detected

module Layout.CaseExpr where

foo x = case x of
   1 -> "a"
   2 -> "b"

