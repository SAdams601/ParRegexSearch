-- A simple let statement, to ensure the layout is detected

module Layout.LetStmt where

foo = do
        let x = 1
            y = 2
        x+y

