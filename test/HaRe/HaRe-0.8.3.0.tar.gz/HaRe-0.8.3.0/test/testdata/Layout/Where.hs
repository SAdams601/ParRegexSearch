module LiftToToplevel.Where where

anotherFun 0 y = sq y
     where sq x = x^2
