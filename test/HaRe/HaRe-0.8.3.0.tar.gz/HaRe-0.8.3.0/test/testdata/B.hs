module B where


bob :: Int -> Int -> Int
bob x y = x + y


