module Main where

import M3

main = do
  putStrLn $ "m3=" ++ (show m3)



