module MoveDef.Demote where

toplevel :: Integer -> Integer
toplevel x = c * x

-- c,d :: Integer
c = 7
d = 9


