module PatBind1 where

tup@(h,t) = (x,1)

x = 2

