module MoveDef.Md1b where

data D = A | C

ff :: Int -> Int
ff y = y + zz
  where
    zz = 1

l z =
  let
    ll = 34
  in ll + z

