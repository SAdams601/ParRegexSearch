module MoveDef.Md1a where

data D = A | B String | C

ff :: Int -> Int
ff y = y + 1

l = 1

