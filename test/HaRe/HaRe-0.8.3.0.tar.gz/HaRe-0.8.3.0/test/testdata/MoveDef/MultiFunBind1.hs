module MoveDef.MultiFunBind1 where

foo 0 = 0
foo x = y + 1

y = 3
