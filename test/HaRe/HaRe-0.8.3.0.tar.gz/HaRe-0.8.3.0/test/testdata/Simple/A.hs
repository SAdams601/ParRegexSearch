module A where
-- Test for refactor of remove bracket

foo = (id)
