module MultiFun1 where

{-

Add a parameter to every equation for the function foo.

-}

foo x [] = []
foo x xs = [1]

foo_x = undefined

