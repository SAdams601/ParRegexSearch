module AddOneParameter.A3 where

import AddOneParameter.D3

main = (sumSquares sumSquares_y) [1..4]

