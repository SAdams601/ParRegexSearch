module AddOneParameter.A3 where

import AddOneParameter.D3

main = sumSquares [1..4]

