module MultiFun1 where

{-

Add a parameter to every equation for the function foo.

-}

foo [] = []
foo xs = [1]

