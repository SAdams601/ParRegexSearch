

data Foo = Ff {fooA :: Integer}

xx = 4

instance Eq Foo where
  a == b = undefined

main = putStrLn "hello"
