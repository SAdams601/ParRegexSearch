module FreeAndDeclared.DeclareS where

-- toplevel :: Integer -> Integer
-- toplevel x = 3 * x
 
c = 'a'

