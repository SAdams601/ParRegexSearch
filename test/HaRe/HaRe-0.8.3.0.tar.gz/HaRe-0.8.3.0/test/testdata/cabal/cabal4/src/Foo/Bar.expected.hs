module Foo.Bar where

baz1 = 6
