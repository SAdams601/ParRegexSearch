
import Foo.Bar

import qualified Foo.Baz as Z

main = putStrLn "hello"

baz = Z.bar + bar1
