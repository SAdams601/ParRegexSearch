module Foo.Bar where

bar1 = 2
