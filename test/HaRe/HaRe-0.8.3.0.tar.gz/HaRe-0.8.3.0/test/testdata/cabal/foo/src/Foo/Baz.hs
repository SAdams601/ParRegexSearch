module Foo.Baz where

bar = 4
