module Foo.Bar where

bar = 2
