module Foo.Bar where

baz = 6
