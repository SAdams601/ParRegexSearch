module M3 (m3) where

import M2

m3 = m2 + 4



