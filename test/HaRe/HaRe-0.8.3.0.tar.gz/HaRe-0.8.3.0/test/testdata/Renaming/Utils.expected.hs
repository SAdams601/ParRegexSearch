module Layout.Utils where

foo :: IO ()
foo = do
      let parsed1 = 3

      let expr = 2
      return ()
