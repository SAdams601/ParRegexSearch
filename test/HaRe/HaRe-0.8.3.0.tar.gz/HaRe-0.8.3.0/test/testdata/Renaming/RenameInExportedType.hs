module Renaming.RenameInExportedType
  (
  MyType
  ) where

data MyType = MT Int


