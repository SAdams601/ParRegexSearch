module Renaming.RenameInExportedType
  (
  NewType
  ) where

data NewType = MT Int


