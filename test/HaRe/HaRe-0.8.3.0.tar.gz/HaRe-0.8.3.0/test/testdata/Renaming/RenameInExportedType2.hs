module Renaming.RenameInExportedType
  (
  MyType (NT)
  ) where

data MyType = MT Int | NT


