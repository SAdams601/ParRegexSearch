module Renaming.RenameInExportedType
  (
  MyType (NewType)
  ) where

data MyType = MT Int | NewType


