module S1 (s1) where

s1 = 7
