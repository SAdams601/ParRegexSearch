{-# OPTIONS_GHC -F -pgmF hspec-discover #-}
{-

See https://github.com/hspec/hspec/tree/master/hspec-discover#readme
to understand this module

-}
